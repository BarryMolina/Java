/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package molina_penniesforpay;

/**
 *
 * @author barrymolina
 */
public class Admin {
	
	public void intro() {
		System.out.println("Welcome to the Salary Calculator app."
				+ "\nThis app calculates how much you would earn if your salary "
				+ "\nwas one cent the first day and doubled everyday after that.");
	}
	public void goodbye() {
		System.out.println("\nGoodbye!");
	}
}
